#include <16F877A.h>
#fuses HS, NOWDT, NOLVP, NOPUT, NOPROTECT
#use delay(clock=20000000)
#define USE_PORTB_LCD TRUE
#include <LCD.C>
#include <string.h>
#define BUZZER PIN_C5  // RC5 i�in




const int led_pins[5] = {PIN_C0, PIN_C1, PIN_C2, PIN_C3, PIN_C4};
const int buton_pins[5] = {PIN_A0, PIN_A1, PIN_A2, PIN_A3, PIN_A4}; 
const char* renkler [5] = {"A", "R", "W","G","B"};  // Renkeleri temsilen ba� harfleri basildi hocaya sor tam string i�in 
const char* sayilar [5] = {"1", "2", "3", "4", "5"};  // Mavi, Sar�, Gri gibi

int sayi[5], renk[5], secim[3], dogru[3];
int puan = 0;

int rastgele_sayi(int min, int max) {
   //return rand() % (max - min + 1) + min;
   static int seed = 0;
   seed += get_timer0();
   if (max <= min) return min;
   return (seed % (max - min + 1)) + min;
}

void sifirla_ledler() {
   for (int i = 0; i < 5; i++) {
      output_high(led_pins[i]);
      delay_ms(10);
      output_low(led_pins[i]);
   }
}

void buzzer_bip() {
    for (int i = 0; i < 3; i++) {
        output_high(BUZZER);
        delay_ms(100);
        output_low(BUZZER);
        delay_ms(100);
    }
}


void main() {
   int i, j,l, t,dogrumu, hedef_sayi, sayac,k = 0;

   setup_timer_0(RTCC_INTERNAL | RTCC_DIV_256);
   set_tris_a(0xFF); // Butonlar giri� i�in 1'e set edildi 
   set_tris_c(0x00); // LED ve buzzer  icin cikis 0'a set edildi
   set_tris_b(0x00); // LCD
   set_tris_d(0b00010000); // Sadece RD4 giri�, di�erleri ��k��

   lcd_init();
   sifirla_ledler();
   output_low(BUZZER);
   

   
   lcd_putc("\fHafiza Oyunu");
   delay_ms(100);
   lcd_putc("\f");

   // 3 say� ve renk �ret
   for (i = 0; i < 3; i++) {
      sayi[i] = rastgele_sayi(1, 5); // LED numaras� 1-5 aras�
      renk[i] = rastgele_sayi(0, 4); // 0: A, 1: R, 2: W
      dogru[i] = 0;
   }

   // LCD'de say� ve renkleri g�ster
   for (i = 0; i < 3; i++) {
   lcd_putc("\fSayi: ");
   printf(lcd_putc, "%u", sayi[i]);
   lcd_gotoxy(1, 2);
   lcd_putc("Renk: ");
   lcd_putc(renkler[renk[i]]);
    //printf(lcd_putc, "%s", renkler[renk[i]]);
   delay_ms(100);
}

   /*for (i = 0; i < 3; i++) {
      lcd_putc("\fSayi: ");
      printf(lcd_putc, "%u", sayi[i]);
      lcd_gotoxy(1,2);
      //printf(lcd_putc, "Renk: %s", renkler[renk[i]]);
      if (renk[i] >= 0 && renk[i] <= 2) {
      printf(lcd_putc, "Renk: %s", renkler[renk[i]]);
      } else {
         lcd_putc("NO");
      }
      delay_ms(1000);
   }*/

   // Hedef renk belirle
   
   //printf(lcd_putc, " %s", renkler[hedef_renk]);
/*char *str = renkler[hedef_renk];
   lcd_putc(str[i]);*/
int toplam_dogru = 0;  // for d�ng�s�n�n d���nda tan�mlanmal�
int toplam_yanlis = 0;
puan = 0;

for (i = 0; i < 3; i++) 
{
    hedef_sayi = rastgele_sayi(0, 4);
    lcd_putc("\fSec:");
    printf(lcd_putc, "%u", sayi[i]);
    delay_ms(50);

    secim[i] = 0;  
    lcd_putc("\fSecim ");
    printf(lcd_putc, "%u", i + 1);
    lcd_gotoxy(1, 2);
    lcd_putc("Butona basin");
    delay_ms(30);

    // Buton okunana kadar bekle
    int buton_bulundu = 0;
    while (!buton_bulundu) {
        for (k = 0; k < 5; k++) {
            if (input(buton_pins[k]) == 1) {
                delay_ms(20); // debounce
                if (input(buton_pins[k]) == 1) {
                    secim[i] = k + 1;
                    t = secim[i];

                    output_high(led_pins[k]);
                    lcd_putc("\fButon Algilandi");
                    printf(lcd_putc, " %u", k + 1);
                    delay_ms(100);
                    output_low(led_pins[k]);

                    lcd_putc("\fSecilen: ");
                    lcd_putc(renkler[t - 1]);
                    delay_ms(100);
                   
                    //************************
                    if(renkler[t - 1] == renkler[renk[i]])
                    {
                     dogru[i] = 1;
                     toplam_dogru++;
                    }else
                    {
                         dogru[i] = 0;
                         toplam_yanlis ++;
                         buzzer_bip(); 
                    }
    
                    
                    
                    
                  //**************************
                    // Buton b�rak�lana kadar bekle
                    while (input(buton_pins[k]) == 1);

                    buton_bulundu = 1;
                    break;
                }
            }
        }

        if (secim[i] != 0) {
            lcd_putc("\fAlindi: ");
            lcd_putc(renkler[t - 1]);
            delay_ms(100);
            output_low(led_pins[k]);
            buton_bulundu = 1;
            break;
        }
    }
}

// T�m se�imler yap�ld�ktan sonra skor kontrol�
/*for (i = 0; i < 3; i++) {
    int secilen_indeks = secim[i] - 1;

    if (secilen_indeks >= 0 && secilen_indeks < 5) {
        if (strcmp(renkler[secilen_indeks], renkler[renk[i]]) == 0) {
            dogru[i] = 1;
            toplam_dogru++;
        } else {
            dogru[i] = 0;
        }
    }
}*/

puan = toplam_dogru * 20 - toplam_yanlis * 5;

lcd_putc("\fSkorunuz:");
lcd_gotoxy(1, 2);
printf(lcd_putc,"%d",puan);
}
