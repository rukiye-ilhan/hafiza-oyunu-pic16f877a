#include <16F877A.h>
#fuses HS, NOWDT, NOLVP, NOPUT, NOPROTECT
#use delay(clock=20 MHz )
#define USE_PORTB_LCD TRUE
#include <LCD.C>

#define BUZZER PIN_C5

// LED pinleri
const int led_pins[5] = {PIN_C0, PIN_C1, PIN_C2, PIN_C3, PIN_C4};
// Buton pinleri
const int buton_pins[5] = {PIN_B0, PIN_B1, PIN_B2, PIN_B3, PIN_B4};
// Renk isimleri
const char* renkler[3] = {"KIRMIZI", "YESIL", "MAVI"};

int sayi[3], renk[3], secim[5], dogru[3];
int puan = 0;

// Basit rastgele fonksiyon (CCS C i�in)
int rastgele_sayi(int min, int max) {
   static int seed = 0;
   seed += get_timer0();  // Timer0 de�eri ile de�i�kenlik
   return (seed % (max - min + 1)) + min;
}

void sifirla_ledler() {
   int i;
   for (i = 0; i < 5; i++) {
      output_low(led_pins[i]);
   }
}

void buzzer_bip() {
   output_high(BUZZER);
   delay_ms(200);
   output_low(BUZZER);
}

void main() {
   int tur, i, j, sayac, dogrumu, hedef_renk;

   setup_timer_0(RTCC_INTERNAL | RTCC_DIV_256); // Timer0 ba�lat
   
   // ?? PIN Y�NLER�N� AYARLADI�IN KISIM
   set_tris_b(0xFF); // PORTB: giri� (butonlar)
   set_tris_c(0x00); // PORTC: ��k�� (LED + buzzer)
   set_tris_d(0x00); // PORTD: ��k�� (LCD)

   
   lcd_init();
   sifirla_ledler();
   output_low(BUZZER);

   lcd_putc("\fHafiza Oyunu");
   delay_ms(1500);

   for (tur = 0; tur < 3; tur++) {
      lcd_putc("\fTur ");
      printf(lcd_putc, "%u", tur + 1);
      delay_ms(1000);
      lcd_putc("\f");

      // Rastgele say� ve renk �ret
      for (i = 0; i < 3; i++) {
         sayi[i] = rastgele_sayi(1, 5);
         renk[i] = rastgele_sayi(0, 2);
         dogru[i] = 0;
      }

      // LCD'de g�ster
      for (i = 0; i < 3; i++) {
         lcd_putc("\fSayi: ");
         printf(lcd_putc, "%u ", sayi[i]);
         lcd_gotoxy(1, 2);
         printf(lcd_putc, "Renk: %s", renkler[renk[i]]);
         delay_ms(1000);
      }

      delay_ms(1000);
      lcd_putc("\f");

      // Hedef renk se�
      hedef_renk = rastgele_sayi(0, 2);
      printf(lcd_putc, "Sec: %s", renkler[hedef_renk]);

      // Giri� al
      for (i = 0; i < 5; i++) {
         secim[i] = 0;
         while (!input(buton_pins[i])); // butona bas�lana kadar bekle
         delay_ms(50);
         while (input(buton_pins[i]));  // b�rak�lana kadar bekle

         output_high(led_pins[i]);

         dogrumu = 0;
         for (j = 0; j < 3; j++) {
            if (sayi[j] == i + 1 && renk[j] == hedef_renk) {
               dogru[j] = 1;
               dogrumu = 1;
               break;
            }
         }

         if (!dogrumu) {
            buzzer_bip();
            if (puan >= 20)
               puan -= 20;
         } else {
            puan += 50;
         }

         delay_ms(500);
      }

      sayac = 0;
      for (i = 0; i < 3; i++) {
         if (dogru[i]) sayac++;
      }

      if (sayac == 3)
         puan += 100;

      delay_ms(1000);
      sifirla_ledler();
      lcd_putc("\fPuan:");
      printf(lcd_putc, " %u", puan);
      delay_ms(1500);
   }

   lcd_putc("\fOyun Bitti");
   lcd_gotoxy(1, 2);
   printf(lcd_putc, "Skor: %u", puan);
   while (true); // sonsuz d�ng�
}

